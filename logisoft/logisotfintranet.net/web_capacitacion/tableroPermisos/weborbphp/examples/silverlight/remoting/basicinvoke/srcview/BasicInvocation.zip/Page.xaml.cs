﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using Weborb.Client;

namespace SilverlightCalculator
{
    public partial class Page : UserControl
    {
        private WeborbClient weborbClient;
        private Weborb.Examples.IBasicService proxy;

        public Page()
        {
            InitializeComponent();
            weborbClient = new WeborbClient( App.WeborbURL, this );
            proxy = weborbClient.Bind<Weborb.Examples.IBasicService>();
        }

        private void DoCalculate( object sender, RoutedEventArgs e )
        {
            int op = 1;

            if( (bool)add.IsChecked )
                op = 1;
            else if( (bool)subtract.IsChecked )
                op = 2;
            else if( (bool)multiply.IsChecked )
                op = 3;
            else if( (bool)divide.IsChecked )
                op = 4;

            AsyncToken<int> result = proxy.Calculate( int.Parse( arg1.Text ),op, int.Parse( arg2.Text ) );
            result.ResultListener += CalcuateResponseListener;
            result.ErrorListener += new ErrorHandler( result_ErrorListener );
        }

        void result_ErrorListener( Fault fault )
        {
            
        }

        void CalcuateResponseListener( int response )
        {
            try
            {
                resultTextBox.Text = response.ToString();
            }
            catch( Exception e )
            {
                String s = e.ToString();
            }
        }
    }
}
