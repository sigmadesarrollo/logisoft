﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using TreeView;
using Weborb.Client;
using Weborb.Types;
namespace SilverlightTreeView
{
    public partial class Page : UserControl
    {
        private WeborbClient proxy;

        public Page()
        {
            InitializeComponent();

            Types.AddClientClassMapping( "Weborb.Examples.FileSystemItem", typeof( FileSystemItem ) );
            Types.AddClientClassMapping( "Weborb.Examples.FolderItem", typeof( FolderItem ) );

            // keep the URL relative - just weborb.aspx for .NET or weborb.php for PHP
            // The API accepts absolute URLs as well
            proxy = new WeborbClient( App.WeborbURL, this );
            this.Loaded += new RoutedEventHandler( Page_Loaded );
        }

        void Page_Loaded( object sender, RoutedEventArgs e )
        {
            Responder<List<FileSystemItem>> responder = new Responder<List<FileSystemItem>>( gotDirectory, null );
            proxy.Invoke( "Weborb.Examples.FileSystemBrowser", "getRoot", null, responder );
        }

        public void gotDirectory( List<FileSystemItem> rootEntries )
        {
            ObservableCollection<TreeViewNode> nodes = null;

            if( fileSystemTree.Selected != null )
                nodes = fileSystemTree.Selected.TreeViewNodes;
            else
                nodes = fileSystemTree.TreeViewNodes;

            foreach( FileSystemItem fileItem in rootEntries )
            {
                TreeViewNode node = new TreeViewNode( 
                    fileItem.fullName, 
                    fileItem.Name, 
                    fileItem is FolderItem, 
                    fileItem is FolderItem ? 
                        "images/Folder-Closed-16x16.png" :
                        "images/Document-16x16.png"
                    );
                node.DataContext = fileItem;
                nodes.Add( node );
            }

            if( fileSystemTree.Selected != null )
                fileSystemTree.Selected.Expand();
        }
        
        private void fileSystemTree_SelectionChanged( object sender, EventArgs e )
        {
            FormRoot.DataContext = ((TreeView.TreeView) sender).Selected.DataContext;
        }
        
        private void fileSystemTree_TreeViewNodeClick( object sender, TreeViewEventArgs e )
        {
            fetchDirectoryInfo( e.Source );
        }

        private void fileSystemTree_Populate( object sender, TreeViewEventArgs e )
        {
            fetchDirectoryInfo( (TreeViewNode)sender );
        }

        private void fetchDirectoryInfo( TreeViewNode treeNode )
        {
            if( treeNode.HasChildren && treeNode.TreeViewNodes.Count == 0 )
            {
                fileSystemTree.Selected = treeNode;
                Responder<List<FileSystemItem>> responder = new Responder<List<FileSystemItem>>( gotDirectory, null );
                proxy.Invoke( "Weborb.Examples.FileSystemBrowser", "getDirectory", new string[] { treeNode.ID }, responder );
            }
        }
    }

    public class FileSystemItem
    {
        public String Name {get;set;}
        public String fullName {get;set;}
        public DateTime createdOn { get; set; }
        public DateTime lastAccessedOn { get; set; }
        public DateTime lastWrittenOn { get; set; }
        public long size { get; set; }
    }

    public class FolderItem : FileSystemItem
    {
        public List<FileSystemItem> Items { get; set; }
    }
}
