﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Browser;

using Weborb.Client;

namespace ClassMapping
{
    public partial class Page : UserControl
    {
        private WeborbClient proxy;

        public Page()
        {
            InitializeComponent();

            int aCode = Convert.ToInt32( 'A' );

            for( int i = 0; i < 26; i++ )
            {
                TabItem newTab = new TabItem();
                TextBlock header = new TextBlock();
                header.Foreground = new SolidColorBrush( Colors.Gray );
                header.Text = Convert.ToChar( aCode + i ).ToString();
                newTab.Header = header;
                newTab.Content = new RosterItem();
                rosterTabs.Items.Add( newTab );
            }

            // keep the URL relative - just weborb.aspx for .NET or weborb.php for PHP
            // The API accepts absolute URLs as well
            proxy = new WeborbClient( App.WeborbURL, this );

            Responder<List<PhoneBookRecord>> token = new Responder<List<PhoneBookRecord>>( gotRecords, null );
            proxy.Invoke( "Weborb.Examples.PhoneBook", "getEntries", null, token );
        }

        public void gotRecords( List<PhoneBookRecord> records )
        {
            foreach( PhoneBookRecord record in records )
                entryAdded( record );
        }

        private void rosterTabs_SelectionChanged( object sender, SelectionChangedEventArgs e )
        {

        }

        private void AddEntryButton_Click( object sender, RoutedEventArgs e )
        {
            AddEntry( newFirstName.Text, newLastName.Text, newPhoneNumber.Text );
        }

        private void AddEntry( string firstName, string lastName, string phoneNumber )
        {
            PhoneBookRecord newRecord = new PhoneBookRecord();
            newRecord.firstName = firstName;
            newRecord.lastName = lastName;
            newRecord.phoneNumber = phoneNumber;

            Responder<PhoneBookRecord> token = new Responder<PhoneBookRecord>( entryAdded, null );
            object[] args = new object[] { newRecord };
            proxy.Invoke( "Weborb.Examples.PhoneBook", "addEntry", args, token );
        }

        public void entryAdded( PhoneBookRecord record )
        {
            int aCode = Convert.ToInt32( 'A' );
            int index = Convert.ToInt32( record.lastName.Substring( 0, 1 ).ToUpper()[ 0 ] ) - aCode;
            TabItem tabItem = (TabItem) rosterTabs.Items.ElementAt( index );

            if( tabItem == null )
            {
                Dispatcher.BeginInvoke( delegate()
                {
                    HtmlPage.Window.Alert( "Last name must start with a letter" );
                } );
                return;
            }

            ((TextBlock) tabItem.Header).Foreground = new SolidColorBrush( Colors.Black );
            ((RosterItem) tabItem.Content).AddRecord( record );
            rosterTabs.SelectedIndex = index;
        }
    }

    public class PhoneBookRecord
    {
        public string firstName {get;set;}
        public string lastName {get;set;}
        public string phoneNumber {get;set;}
    }
}
