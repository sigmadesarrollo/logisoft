﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace ClassMapping
{
    public partial class RosterItem : UserControl
    {
        private RosterListModel _model = new RosterListModel();

        public RosterItem()
        {
            InitializeComponent();
            LayoutRoot.DataContext = _model;
        }

        public void AddRecord( PhoneBookRecord record )
        {
            _model.AddRecord( record );
            // THIS IS A HACK. I COULD NOT DO ANYTHING TO GET THE DATABINDING WORKING.
            // PLEASE LET US KNOW IF YOU CAN THINK OF A WORKAROUND WITHOUT THIS LINE
            // SEND YOUR SUGGESTIONS TO mark@themidnightcoders.com
            phoneEntries.ItemsSource = new List<PhoneBookRecord>( _model.Records );
        }
    }

    public class RosterListModel :INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private List<PhoneBookRecord> _records;

        public List<PhoneBookRecord> Records
        {
            get
            {
                if( _records == null )
                    _records = new List<PhoneBookRecord>();

                return _records;
            }
        }

        public void AddRecord( PhoneBookRecord record )
        {
            Records.Add( record );

            if( PropertyChanged != null )
            {
                PropertyChanged( this, new PropertyChangedEventArgs( "Records" ) );
            }
        }
    }
}
