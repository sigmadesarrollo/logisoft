﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

using Weborb.Client;

namespace SilverlightComplexTypeTest
{
    public partial class Page : UserControl
    {
        public List<string> eyeColors = new List<string>() { "Blue", "Brown", "Green", "Transparent", "Red" };

        private WeborbClient weborbClient;        
        private Identity receivedIdentity;
       
        public Page()
        {
            InitializeComponent();
            eyeColor.ItemsSource = eyeColors;
            // keep the URL relative - just weborb.aspx for .NET or weborb.php for PHP
            // The API accepts absolute URLs as well
            weborbClient = new WeborbClient( App.WeborbURL, this );
        }

        public Identity ReceivedIdentity
        {
            get { return receivedIdentity; }
            set 
            {
                receivedIdentity = value; 
                ReceivedIdentityRoot.DataContext = value;
            }
        }

        private void ageSlider_ValueChanged( object sender, RoutedPropertyChangedEventArgs<double> e )
        {
            if( sliderValueDisplay != null )
                sliderValueDisplay.Text = ((int)((Slider) sender).Value).ToString();
        }

        private void TransformObject( object sender, RoutedEventArgs e )
        {
            Identity identityFromClient = new Identity();
            identityFromClient.age = (int) ageSlider.Value;
            identityFromClient.name = nameField.Text;
            identityFromClient.sex = (bool)male.IsChecked ? "male" : "female";
            identityFromClient.eyeColor = (string)eyeColor.SelectedItem;
            Responder<Identity> responder = new Responder<Identity>( token_ResultListener, null );
            weborbClient.Invoke( "Weborb.Examples.IdentityService", "HideIdentity", new object[] { identityFromClient }, responder );
        }

        void token_ResultListener( Identity response )
        {
            ReceivedIdentity = response;
        }
    }
}
