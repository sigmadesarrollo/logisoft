﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace SilverlightComplexTypeTest
{
    public class Identity
    {
        private String _name;
        private int _age;
        private String _sex;
        private string _eyeColor;

        public string name
        {
            get { return _name; }
            set { _name = value; }
        }

        public int age
        {
            get { return _age; }
            set { _age = value; }
        }

        public string sex
        {
            get { return _sex; }
            set { _sex = value; }
        }

        public string eyeColor
        {
            get { return _eyeColor; }
            set { _eyeColor = value; }
        }
    }
}
