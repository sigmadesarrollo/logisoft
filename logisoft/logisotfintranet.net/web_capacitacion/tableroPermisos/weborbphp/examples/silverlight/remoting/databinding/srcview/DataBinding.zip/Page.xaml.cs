﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using Weborb.Client;
namespace DataGridDataBinding
{
    public partial class Page : UserControl
    {
        private WeborbClient proxy;

        public Page()
        {
            InitializeComponent();
            // keep the URL relative - just weborb.aspx for .NET or weborb.php for PHP. 
            // The API accepts absolute URLs as well
            proxy = new WeborbClient( App.WeborbURL, this );
            this.Loaded += new RoutedEventHandler( Page_Loaded );
        }

        void Page_Loaded( object sender, RoutedEventArgs e )
        {
            Responder<List<Customer>> responder = new Responder<List<Customer>>( GotCustomers, null );
            proxy.Invoke( "Weborb.Examples.DataBinding", "getCustomers", null, responder );
        }

        public void GotCustomers( List<Customer> customers )
        {
            customersGrid.ItemsSource = customers;
        }
    }

    public class Customer
    {
        public string ContactName { get; set; }
        public string City { get; set; }
    }
}
